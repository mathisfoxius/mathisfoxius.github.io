import random

class Task:
    def __init__(self,temps):
        self.timeStamp = temps
        self.pages = random.randrange(1,21)

    def getTimeStamp(self):
        return self.timeStamp

    def getNbrPages(self):
        return self.pages

    def taskWaitingTime(self, timeNow):
        return timeNow - self.timeStamp
