from Task import *

class Printer:
    def __init__(self,nom,ppm):

        self.printSpeed = ppm
        self.currentTask = None
        self.remainingTime = 0
        self.name = nom

    def busy(self):

        if self.currentTask != None:
            return True
        else:
            return False

    def tick(self):
        if self.currentTask != None:
            self.remainingTime = self.remainingTime - 1
            if self.remainingTime <= 0:
                self.currentTask = None

    def startNextJob(self, task):
        self.currentTask = task
        self.remainingTime = task.getNbrPages() * 60 / self.printSpeed