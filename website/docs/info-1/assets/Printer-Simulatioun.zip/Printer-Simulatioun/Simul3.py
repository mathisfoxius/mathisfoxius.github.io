from Queue import *
from Printer import *
from Task import *


def simulation(nbrSeconds, ppm):
    def newPrintTask():
        num = random.randrange(1, 120)
        if num == 1:
            return True
        else:
            return False

    printer1 = Printer('Bureau', ppm)
    pq = Queue()
    waitingTime = []

    for second in range(nbrSeconds):
        if newPrintTask():
            task = Task(second)
            pq.enqueue(task)
        if (not printer1.busy()) and (not pq.empty()):
            newTask = pq.top()
            pq.dequeue()
            waitingTime.append(newTask.taskWaitingTime(second))
            printer1.startNextJob(newTask)

        printer1.tick()

    return sum(waitingTime) / len(waitingTime)



x = []
y = []
nbrSimulations = 10
for ppm in range(6, 20):
    sumWaitingTime = 0
    for i in range(nbrSimulations):
        sumWaitingTime = sumWaitingTime + simulation(28800, ppm)
    x.append(ppm)
    y.append(sumWaitingTime / nbrSimulations)

import matplotlib.pyplot as plt

plt.scatter(x, y)
plt.title('Simulation du temps d\'attente lors d\'impressions')
plt.xlabel('Vitesse d\'impression de l\'imprimante en ppm')
plt.ylabel('Temps d\'attente en secondes')
plt.show()